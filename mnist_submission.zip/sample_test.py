"""
Sample Test Script - Demonstrates model usage without command line.
Useful for Jupyter notebooks and interactive environments.
"""

import os
import numpy as np
from PIL import Image
from tensorflow import keras
import pandas as pd


def predict_single_image(image_path, model_path='best_model.keras'):
    """Predict digit from a single image."""
    # Load model
    model = keras.models.load_model(model_path)
    
    # Load and preprocess image
    img = Image.open(image_path).convert('L')
    img = img.resize((28, 28), Image.Resampling.LANCZOS)
    img_array = np.array(img).astype('float32') / 255.0
    
    # Auto-invert if needed
    if np.mean(img_array) > 0.5:
        img_array = 1.0 - img_array
    
    # Reshape and predict
    img_array = img_array.reshape(1, 28, 28, 1)
    prediction = model.predict(img_array, verbose=0)[0]
    
    digit = int(np.argmax(prediction))
    confidence = float(prediction[digit] * 100)
    
    return digit, confidence


def predict_directory(directory_path, model_path='best_model.keras'):
    """Predict digits for all images in a directory."""
    model = keras.models.load_model(model_path)
    
    results = []
    image_files = [f for f in os.listdir(directory_path)
                   if f.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp'))]
    
    for image_file in sorted(image_files):
        image_path = os.path.join(directory_path, image_file)
        
        # Preprocess
        img = Image.open(image_path).convert('L')
        img = img.resize((28, 28), Image.Resampling.LANCZOS)
        img_array = np.array(img).astype('float32') / 255.0
        
        if np.mean(img_array) > 0.5:
            img_array = 1.0 - img_array
        
        img_array = img_array.reshape(1, 28, 28, 1)
        
        # Predict
        prediction = model.predict(img_array, verbose=0)[0]
        digit = int(np.argmax(prediction))
        confidence = float(prediction[digit] * 100)
        
        results.append({
            'filename': image_file,
            'prediction': digit,
            'confidence': confidence
        })
    
    return pd.DataFrame(results)


if __name__ == "__main__":
    # Example 1: Single image
    print("Example 1: Predicting single image")
    digit, conf = predict_single_image('sample_image.png')
    print(f"  Digit: {digit}, Confidence: {conf:.2f}%")
    
    # Example 2: Directory
    print("\nExample 2: Predicting directory")
    df = predict_directory('./test_images')
    print(df.to_string())
    df.to_csv('predictions.csv', index=False)

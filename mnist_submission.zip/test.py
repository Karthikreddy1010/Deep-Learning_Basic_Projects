"""
Enhanced MNIST Digit Prediction Script
======================================

Features:
- Supports multiple image formats
- Automatic image preprocessing
- Confidence scoring
- Batch processing
- CSV export

Usage:
    python test.py <input_directory>
    
Example:
    python test.py ./test_images
"""

import sys
import os
import pandas as pd
import numpy as np
from tensorflow import keras
from PIL import Image
import warnings
warnings.filterwarnings('ignore')

# Configuration
MODEL_PATH = 'best_model.keras'
OUTPUT_CSV = 'predictions.csv'
VALID_EXTENSIONS = ('.png', '.jpg', '.jpeg', '.bmp', '.tiff', '.tif', '.gif')


def load_model(model_path=MODEL_PATH):
    """Load the pre-trained model with error handling."""
    if not os.path.exists(model_path):
        raise FileNotFoundError(f"Model file not found: {model_path}")
    
    try:
        model = keras.models.load_model(model_path)
        print(f"✓ Model loaded successfully: {model_path}")
        print(f"  Architecture: {model.name}")
        print(f"  Total parameters: {model.count_params():,}")
        return model
    except Exception as e:
        raise RuntimeError(f"Failed to load model: {e}")


def preprocess_image(image_path, target_size=(28, 28)):
    """
    Load and preprocess image for MNIST prediction.
    
    Args:
        image_path: Path to image file
        target_size: Target size for resizing (default: 28x28)
    
    Returns:
        Preprocessed image array ready for prediction
    """
    try:
        # Load image and convert to grayscale
        img = Image.open(image_path).convert('L')
        
        # Resize to target size
        img = img.resize(target_size, Image.Resampling.LANCZOS)
        
        # Convert to numpy array
        img_array = np.array(img)
        
        # Auto-invert if background is white (inverted MNIST)
        if np.mean(img_array) > 127:
            img_array = 255 - img_array
        
        # Normalize to [0, 1]
        img_array = img_array.astype('float32') / 255.0
        
        # Reshape for CNN input: (28, 28, 1)
        img_array = img_array.reshape(1, target_size[0], target_size[1], 1)
        
        return img_array
    
    except Exception as e:
        raise ValueError(f"Failed to preprocess image {image_path}: {e}")


def predict_digit(model, img_array):
    """
    Predict digit class and confidence.
    
    Args:
        model: Trained Keras model
        img_array: Preprocessed image array
    
    Returns:
        Tuple of (predicted_digit, confidence_score)
    """
    predictions = model.predict(img_array, verbose=0)[0]
    predicted_digit = int(np.argmax(predictions))
    confidence = float(predictions[predicted_digit] * 100)
    
    return predicted_digit, confidence


def process_batch(image_files, input_dir, model, batch_size=32):
    """
    Process images in batches for efficiency.
    
    Args:
        image_files: List of image filenames
        input_dir: Input directory path
        model: Trained model
        batch_size: Number of images to process at once
    
    Returns:
        List of prediction dictionaries
    """
    predictions = []
    
    for i in range(0, len(image_files), batch_size):
        batch = image_files[i:i+batch_size]
        
        for image_file in batch:
            try:
                image_path = os.path.join(input_dir, image_file)
                img_array = preprocess_image(image_path)
                pred_digit, confidence = predict_digit(model, img_array)
                
                predictions.append({
                    'filename': image_file,
                    'prediction': pred_digit,
                    'confidence': round(confidence, 2)
                })
                
                print(f"  ✓ {image_file:40s} → Digit: {pred_digit}  "
                      f"(Confidence: {confidence:6.2f}%)")
            
            except Exception as e:
                print(f"  ✗ {image_file:40s} → ERROR: {str(e)[:50]}")
                predictions.append({
                    'filename': image_file,
                    'prediction': -1,
                    'confidence': 0.0
                })
    
    return predictions


def validate_directory(input_dir):
    """Validate input directory and check for images."""
    if not os.path.isdir(input_dir):
        raise NotADirectoryError(f"Input directory not found: {input_dir}")
    
    image_files = [f for f in os.listdir(input_dir)
                   if f.lower().endswith(VALID_EXTENSIONS)]
    
    if not image_files:
        raise FileNotFoundError(
            f"No image files found in '{input_dir}'. "
            f"Supported: {', '.join(VALID_EXTENSIONS)}"
        )
    
    return sorted(image_files)


def process_images(input_dir, model_path=MODEL_PATH):
    """
    Main processing function: Load images, predict, and save results.
    
    Args:
        input_dir: Directory containing test images
        model_path: Path to trained model file
    
    Returns:
        pandas DataFrame with predictions
    """
    print(f"\n{'='*80}")
    print(f"Processing images from: {input_dir}")
    print(f"{'='*80}")
    
    # Validate directory
    try:
        image_files = validate_directory(input_dir)
    except Exception as e:
        print(f"\n❌ Error: {e}")
        return None
    
    # Load model
    try:
        model = load_model(model_path)
    except Exception as e:
        print(f"\n❌ Error loading model: {e}")
        return None
    
    # Process images
    print(f"\n🔍 Found {len(image_files)} images. Processing...\n")
    
    try:
        predictions = process_batch(image_files, input_dir, model)
    except Exception as e:
        print(f"\n❌ Error during processing: {e}")
        return None
    
    # Create DataFrame
    df = pd.DataFrame(predictions)
    
    # Statistics
    print(f"\n{'='*80}")
    successful = df[df['prediction'] != -1]
    failed = df[df['prediction'] == -1]
    
    print(f"📊 Processing Summary:")
    print(f"  Total images:     {len(df)}")
    print(f"  Successful:       {len(successful)}")
    print(f"  Failed:           {len(failed)}")
    
    if len(successful) > 0:
        print(f"\n  Average confidence: {successful['confidence'].mean():.2f}%")
        print(f"  Min confidence:     {successful['confidence'].min():.2f}%")
        print(f"  Max confidence:     {successful['confidence'].max():.2f}%")
    
    # Save predictions
    df.to_csv(OUTPUT_CSV, index=False)
    print(f"\n✅ Predictions saved to: {OUTPUT_CSV}")
    print(f"{'='*80}")
    
    return df


def main():
    """Main function for command-line execution."""
    if len(sys.argv) < 2:
        print(f"Usage: python {sys.argv[0]} <input_directory> [model_path]")
        print(f"\nExample: python {sys.argv[0]} ./test_images")
        print(f"          python {sys.argv[0]} ./test_images best_model.keras")
        return 1
    
    input_dir = sys.argv[1]
    model_path = sys.argv[2] if len(sys.argv) > 2 else MODEL_PATH
    
    try:
        process_images(input_dir, model_path)
        return 0
    except Exception as e:
        print(f"\n❌ Fatal error: {e}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
